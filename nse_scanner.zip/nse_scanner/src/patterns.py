"""
patterns.py — pivot detection and W-pattern (double bottom) identification.

THE LOOK-AHEAD RULE
-------------------
A pivot low with right-window R is only KNOWABLE R bars after it forms.
Every pattern this module returns carries `confirm_pos` — the earliest bar at
which you could have known about it. Backtests and live scans must both use
confirm_pos, never the pivot's own date.

Getting this wrong makes a backtest look excellent and a live scanner look
broken, and the two will never reconcile.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List, Optional

import numpy as np
import pandas as pd


# ---------------------------------------------------------------- pivots

def pivot_lows(low: pd.Series, left: int = 3, right: int = 3) -> np.ndarray:
    """
    Positions of pivot lows: a bar whose Low is strictly lower than `left`
    bars before and `right` bars after.

    Returns integer positions (not dates).
    """
    v = low.to_numpy(dtype=float)
    n = len(v)
    out = []
    for i in range(left, n - right):
        window_l = v[i - left:i]
        window_r = v[i + 1:i + right + 1]
        if np.isnan(v[i]) or np.isnan(window_l).any() or np.isnan(window_r).any():
            continue
        if v[i] < window_l.min() and v[i] < window_r.min():
            out.append(i)
    return np.array(out, dtype=int)


def pivot_highs(high: pd.Series, left: int = 3, right: int = 3) -> np.ndarray:
    """Positions of pivot highs. Mirror of pivot_lows."""
    v = high.to_numpy(dtype=float)
    n = len(v)
    out = []
    for i in range(left, n - right):
        wl = v[i - left:i]
        wr = v[i + 1:i + right + 1]
        if np.isnan(v[i]) or np.isnan(wl).any() or np.isnan(wr).any():
            continue
        if v[i] > wl.max() and v[i] > wr.max():
            out.append(i)
    return np.array(out, dtype=int)


def last_n_pivot_lows(low: pd.Series, n: int = 3, left: int = 3, right: int = 3):
    """The most recent n confirmed pivot lows, newest first."""
    piv = pivot_lows(low, left, right)
    return piv[-n:][::-1] if len(piv) else np.array([], dtype=int)


# ---------------------------------------------------------------- w-pattern

@dataclass
class WPattern:
    """One detected double bottom. All positions are integer bar offsets."""
    l1_pos: int
    l1_price: float
    l2_pos: int
    l2_price: float
    neckline_pos: int
    neckline: float
    confirm_pos: int          # earliest bar you could have known (L2 + right)
    depth_pct: float          # neckline to L2, as % of neckline
    separation: int           # bars between the two bottoms
    tolerance_atr: float      # |L2-L1| expressed in ATR units
    undercut: bool            # did L2 dip below L1

    def to_dict(self) -> dict:
        return asdict(self)


def find_w_patterns(
    df: pd.DataFrame,
    atr_series: pd.Series,
    left: int = 3,
    right: int = 3,
    min_separation: int = 10,
    max_separation: int = 60,
    tol_atr: float = 0.5,
    require_undercut: bool = True,
    min_depth_pct: float = 3.0,
    exclude_locked_bars: bool = True,
) -> List[WPattern]:
    """
    Find double bottoms.

    Rules (all configurable, defaults from the design doc):
      - Two confirmed pivot lows, `min_separation`..`max_separation` bars apart
      - |L2 - L1| <= tol_atr * ATR(at L2)   -- ATR-based, NOT a flat percentage,
        so the tolerance adapts to each stock's own volatility
      - L2 < L1 when require_undercut (the user's stated variant: the second low
        undercuts the prior swing low, i.e. a shakeout)
      - Neckline = highest high strictly between the two bottoms
      - Depth (neckline to L2) >= min_depth_pct, so we skip flat noise

    df needs columns: high, low, close.
    """
    required = {"high", "low", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"find_w_patterns: df missing columns {sorted(missing)}")

    low = df["low"]
    high = df["high"]
    close = df["close"]

    # Circuit-locked bars (high == low == close) create fake pivot lows.
    # Blank them out so they cannot anchor a pattern.
    if exclude_locked_bars:
        locked = (high == low) & (low == close)
        low = low.mask(locked)
        high = high.mask(locked)

    piv = pivot_lows(low, left, right)
    if len(piv) < 2:
        return []

    lows_arr = low.to_numpy(dtype=float)
    highs_arr = high.to_numpy(dtype=float)
    atr_arr = atr_series.to_numpy(dtype=float)

    results: List[WPattern] = []

    for a in range(len(piv) - 1):
        for b in range(a + 1, len(piv)):
            i1, i2 = int(piv[a]), int(piv[b])
            sep = i2 - i1
            if sep < min_separation:
                continue
            if sep > max_separation:
                break  # piv is sorted; further b only gets larger

            p1, p2 = lows_arr[i1], lows_arr[i2]
            if np.isnan(p1) or np.isnan(p2):
                continue

            atr_at_l2 = atr_arr[i2]
            if np.isnan(atr_at_l2) or atr_at_l2 <= 0:
                continue

            diff_in_atr = abs(p2 - p1) / atr_at_l2
            if diff_in_atr > tol_atr:
                continue

            if require_undercut and not (p2 < p1):
                continue

            between = highs_arr[i1 + 1:i2]
            if len(between) == 0:
                continue
            neck_rel = int(np.nanargmax(between))
            neck_pos = i1 + 1 + neck_rel
            neckline = float(between[neck_rel])
            if np.isnan(neckline) or neckline <= 0:
                continue

            depth_pct = (neckline - p2) / neckline * 100.0
            if depth_pct < min_depth_pct:
                continue

            results.append(
                WPattern(
                    l1_pos=i1,
                    l1_price=float(p1),
                    l2_pos=i2,
                    l2_price=float(p2),
                    neckline_pos=neck_pos,
                    neckline=neckline,
                    confirm_pos=i2 + right,      # <-- the look-ahead guard
                    depth_pct=float(depth_pct),
                    separation=int(sep),
                    tolerance_atr=float(diff_in_atr),
                    undercut=bool(p2 < p1),
                )
            )

    return _dedupe_by_l2(results)


def _dedupe_by_l2(patterns: List[WPattern]) -> List[WPattern]:
    """
    One pattern per second-bottom. When several L1 candidates pair with the
    same L2, keep the tightest match (smallest ATR difference).
    """
    best: dict[int, WPattern] = {}
    for p in patterns:
        cur = best.get(p.l2_pos)
        if cur is None or p.tolerance_atr < cur.tolerance_atr:
            best[p.l2_pos] = p
    return [best[k] for k in sorted(best)]


# ---------------------------------------------------------------- entry triggers

def find_entry_trigger(
    df: pd.DataFrame,
    pattern: WPattern,
    variant: str,
    extra: Optional[dict] = None,
    max_wait: int = 30,
) -> Optional[int]:
    """
    Find the bar position where a given entry rule first fires, searching
    forward from pattern.confirm_pos.

    Variants (see the design doc, Backtest section):
      E1  next bar after confirmation   -- earliest, most trades, most failures
      E2  close above L1                -- the "reclaim" rule; shakeout confirmed
      E3  close above neckline          -- latest, best win rate, worst R:R
      E4  close above SMA20             -- momentum confirmation
      E5  close above AVWAP anchored at L1

    Returns the SIGNAL bar position, or None if the rule never fires within
    max_wait bars. Entry itself happens at the NEXT bar's open — see backtest.py.
    """
    extra = extra or {}
    n = len(df)
    start = pattern.confirm_pos
    if start >= n:
        return None

    stop_at = min(n, start + max_wait + 1)
    close = df["close"].to_numpy(dtype=float)

    if variant == "E1":
        return start if start < n else None

    if variant == "E2":
        level = pattern.l1_price
        for i in range(start, stop_at):
            if close[i] > level:
                return i
        return None

    if variant == "E3":
        level = pattern.neckline
        for i in range(start, stop_at):
            if close[i] > level:
                return i
        return None

    if variant == "E4":
        sma20 = extra.get("sma20")
        if sma20 is None:
            return None
        s = np.asarray(sma20, dtype=float)
        for i in range(start, stop_at):
            if not np.isnan(s[i]) and close[i] > s[i]:
                return i
        return None

    if variant == "E5":
        av = extra.get("avwap_l1")
        if av is None:
            return None
        a = np.asarray(av, dtype=float)
        for i in range(start, stop_at):
            if not np.isnan(a[i]) and close[i] > a[i]:
                return i
        return None

    raise ValueError(f"Unknown entry variant: {variant}")


# ---------------------------------------------------------------- classification

def classify_bottom_vs_sma(
    df: pd.DataFrame,
    pattern: WPattern,
    sma_cols: dict,
    atr_series: pd.Series,
    within_atr: float = 1.0,
) -> str:
    """
    Which moving average did the second bottom form on?

    Returns 'at_sma20' | 'at_sma50' | 'at_sma100' | 'at_sma200' | 'none'.

    This is a CLASSIFIER, not a filter. A W bottoming at the 200 DMA is a
    different animal from one forming in mid-air, and slicing results this way
    is likely the most informative cut in the whole study.

    sma_cols: {'sma20': Series, 'sma50': Series, ...}
    """
    i = pattern.l2_pos
    price = pattern.l2_price
    a = atr_series.to_numpy(dtype=float)[i]
    if np.isnan(a) or a <= 0:
        return "none"

    best_name, best_dist = "none", np.inf
    for name in ("sma20", "sma50", "sma100", "sma200"):
        s = sma_cols.get(name)
        if s is None:
            continue
        val = np.asarray(s, dtype=float)[i]
        if np.isnan(val):
            continue
        d = abs(price - val) / a
        if d <= within_atr and d < best_dist:
            best_name, best_dist = f"at_{name}", d
    return best_name


def sma_stack_state(row: pd.Series) -> str:
    """
    Moving-average alignment at the signal bar.
      'stacked_up'   10>20>50>100>200  (clean uptrend)
      'stacked_down' 10<20<50<100<200  (clean downtrend)
      'mixed'        anything else
    """
    keys = ["sma10", "sma20", "sma50", "sma100", "sma200"]
    vals = [row.get(k) for k in keys]
    if any(v is None or (isinstance(v, float) and np.isnan(v)) for v in vals):
        return "unknown"
    if all(vals[i] > vals[i + 1] for i in range(len(vals) - 1)):
        return "stacked_up"
    if all(vals[i] < vals[i + 1] for i in range(len(vals) - 1)):
        return "stacked_down"
    return "mixed"


def sma_compression_pct(row: pd.Series) -> float:
    """
    How tightly the moving averages are clustered, as % of price.
    Low values mean a coiled spring; breakouts from compression tend to run.
    """
    keys = ["sma10", "sma20", "sma50", "sma100", "sma200"]
    vals = [row.get(k) for k in keys]
    vals = [v for v in vals if v is not None and not (isinstance(v, float) and np.isnan(v))]
    if len(vals) < 2 or not row.get("close"):
        return float("nan")
    return (max(vals) - min(vals)) / row["close"] * 100.0
