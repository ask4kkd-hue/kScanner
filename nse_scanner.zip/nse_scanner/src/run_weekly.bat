@echo off
REM ===================================================================
REM  WEEKLY FULL REBUILD - do not skip this.
REM
REM  Corporate actions retroactively change history and yfinance
REM  silently restates past bars. Incremental updates never catch
REM  either. This is how wrong history quietly accumulates in most
REM  home-built scanners.
REM ===================================================================
cd /d "%~dp0"
call .venv\Scripts\activate

python universe.py
python ingest.py
python validate.py --days 5
python features.py --full

echo.
echo Full rebuild complete.
